export const MODES = [
  {id:'context',name:'Investigate',product:'CONTEXT',verb:'Understand what is true',caption:'Evidence, provenance, and missing context',color:'#8574ff',subtitle:'What’s the full story?'},
  {id:'prelude',name:'Anticipate',product:'PRELUDE',verb:'See risk before it unfolds',caption:'Motion, trajectories, and emerging risk',color:'#8574ff',subtitle:'What might happen next?'},
  {id:'veil',name:'Protect',product:'VEIL',verb:'Make video safe to share',caption:'Privacy detection, protection, and auditing',color:'#8574ff',subtitle:'What should stay private?'},
  {id:'control',name:'Experiment',product:'CONTROL',verb:'Challenge a conclusion',caption:'Variables, observations, and causal reasoning',color:'#8574ff',subtitle:'What does the evidence prove?'}
]

// Seeded illustrations for UI exploration — not AI-generated findings.
export const SCENARIOS = {
  context: {
    title:'The missing sentence', short:'A clipped conference talk', duration:72,
    image:'/scenes/context.svg',
    credit:'Original vector illustration bundled with the prototype',
    label:'SAMPLE INVESTIGATION', flag:'Meaning may change', tag:'Clip comparison',
    insight:'An intervening statement was removed from the published sequence. The effect on meaning needs source review.',
    facts:[
      {id:'c1',time:14,severity:'source',label:'Matching source segment',sub:'An aligned segment appears in the longer recording.',detail:'A source interval corresponds to the selected portion of the published clip. Alignment is a technical observation, not a truth verdict.'},
      {id:'c2',time:31,severity:'attention',label:'Potentially relevant omission',sub:'00:31–00:47 · 16 seconds missing',detail:'A segment between two matched intervals is absent in the shortened recording. A human should inspect whether the missing statement changes interpretation.'},
      {id:'c3',time:54,severity:'neutral',label:'Context still unresolved',sub:'Narrative significance requires review',detail:'Video authenticity and editorial intent cannot be determined from cut detection alone.'}
    ],
    sources:[{title:'Full talk · original recording',meta:'Linked source · illustrative',kind:'Video source'},{title:'Transcript · full excerpt',meta:'Time-coded context · illustrative',kind:'Transcript'}]
  },
  prelude: {
    title:'Intersection approach',short:'Motion and proximity study',duration:42,
    image:'/scenes/prelude.svg',
    credit:'Original vector illustration bundled with the prototype',
    label:'SAMPLE RISK REVIEW',flag:'Potential path conflict',tag:'Trajectory analysis',
    insight:'Two movement paths appear to converge in this illustrated scenario. A real alert would require calibrated tracking and time-to-conflict estimates.',
    facts:[
      {id:'p1',time:10,severity:'source',label:'Two actors in view',sub:'Object tracks and approximate positions',detail:'A grounded risk analysis must track stable object IDs over time before projecting possible paths.'},
      {id:'p2',time:22,severity:'attention',label:'Possible converging paths',sub:'Illustrative early warning',detail:'This sample suggests a potential overlap of trajectories. It is not a validated collision prediction or a driver-assistance safety alert.'},
      {id:'p3',time:35,severity:'neutral',label:'Outcome not established',sub:'Insufficient physical parameters',detail:'Camera calibration, velocity and motion uncertainty must be evaluated before making a prediction.'}
    ],
    sources:[{title:'Motion track A',meta:'Visual track · illustrative',kind:'Track'},{title:'Motion track B',meta:'Visual track · illustrative',kind:'Track'}]
  },
  veil: {
    title:'A private detail in plain sight',short:'Sensitive-content protection',duration:55,
    image:'/scenes/veil.svg',
    credit:'Original vector illustration bundled with the prototype',
    label:'SAMPLE PRIVACY REVIEW',flag:'Sensitive content found',tag:'Privacy inspection',
    insight:'Sensitive on-screen information needs review before sharing. Protection is only complete after inspecting the exported media.',
    facts:[
      {id:'v1',time:11,severity:'attention',label:'Screen text region',sub:'00:11–00:29 · review suggested',detail:'The UI illustrates a potential screen-text exposure. The image itself has not been analyzed for sensitive information.'},
      {id:'v2',time:24,severity:'attention',label:'Audio disclosure check',sub:'Speech verification required',detail:'An actual audit must inspect spoken personal data independently of visual privacy masks.'},
      {id:'v3',time:41,severity:'source',label:'Export audit',sub:'Run after applying protection',detail:'Final exports must be checked independently. A visual overlay alone is not sufficient evidence of privacy.'}
    ],
    sources:[{title:'Visual regions',meta:'Illustrative · 1 region',kind:'Privacy'},{title:'Audio transcript',meta:'Not processed',kind:'Speech'}]
  },
  control: {
    title:'The experiment that changed twice',short:'Investigate a scientific claim',duration:64,
    image:'/scenes/control.svg',
    credit:'Original vector illustration bundled with the prototype',
    label:'SAMPLE EXPERIMENT REVIEW',flag:'Confounding variable',tag:'Experiment validity',
    insight:'A claim of causation requires controlled conditions. The sample demonstrates how an assistant could identify two changing variables.',
    facts:[
      {id:'x1',time:12,severity:'source',label:'Baseline observation',sub:'Initial experimental state',detail:'The baseline should be measured independently. A vision model might miss small but relevant apparatus changes.'},
      {id:'x2',time:28,severity:'attention',label:'Second variable changed',sub:'Potential confounding factor',detail:'The illustrated comparison changes both input and environmental conditions, preventing a clean causal attribution.'},
      {id:'x3',time:51,severity:'neutral',label:'Control recommended',sub:'Repeat with one variable changed',detail:'A controlled follow-up should hold other variables constant and report uncertainty.'}
    ],
    sources:[{title:'Observed conditions',meta:'Illustrative variables',kind:'Experiment'},{title:'Control suggestions',meta:'Requires physical validation',kind:'Method'}]
  }
}
