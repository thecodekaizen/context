import React, {useCallback, useEffect, useMemo, useRef, useState} from 'react'
import {
 Activity, ArrowDownToLine, ArrowLeftRight, ArrowRight, AudioLines, Beaker,
 Bell, Bookmark, Check, CheckCheck, ChevronDown, ChevronLeft, ChevronRight,
 CircleAlert, CircleCheck, CircleHelp, Clock3, Command, Copy, Ellipsis,
 Expand, ExternalLink, Eye, EyeOff, FileText, Film, Fingerprint, FolderOpen,
 Gauge, HelpCircle, History, Layers3, Link2, Menu, MessageSquareQuote, Mic2,
 Moon, MoreHorizontal, MousePointer2, MoveUpRight, Pause, Play, Plus,
 Radar, RotateCcw, ScanEye, Search, Settings2, Shield, ShieldCheck, SkipBack,
 SkipForward, SlidersHorizontal, Sparkles, Sun, Upload, Video, Volume2,
 VolumeX, WandSparkles, X
} from 'lucide-react'
import {MODES, SCENARIOS} from './data.js'

const MODE_ICONS = {context: ScanEye, prelude: Radar, veil: ShieldCheck, control: Beaker}
const range = (v,lo,hi) => Math.max(lo,Math.min(hi,v))
const pad = n => String(Math.floor(n)).padStart(2,'0')
const clock = n => `${pad(n/60)}:${pad(n%60)}`

function IconButton({icon: Icon,label,onClick,selected=false,className=''}) { return <button className={`icon-button ${selected?'icon-selected':''} ${className}`} title={label} aria-label={label} onClick={onClick}><Icon size={17}/></button> }
function Eyebrow({children}){return <span className="eyebrow">{children}</span>}
function StatusDot({state='ready'}){return <span className={`status-dot ${state}`} aria-hidden="true"/>}
function Tooltip({children}){return <span className="subtle-hint">{children}</span>}

function Sidebar({active,onChange,mobileOpen,onClose,onNew}){
 return <>
  {mobileOpen&&<div className="mobile-scrim" onClick={onClose}/>}
  <aside className={`sidebar ${mobileOpen?'mobile-open':''}`}>
   <div className="brand-row"><div className="brand-symbol"><ScanEye size={19} strokeWidth={2.3}/></div><div className="brand-label">context<span className="brand-period">.</span></div><span className="brand-beta">LAB</span><button className="mobile-close icon-button" onClick={onClose}><X size={16}/></button></div>
   <div className="sidebar-inner">
    <button className="new-project" onClick={()=>{onNew();onClose()}}><Plus size={17}/> New investigation <span className="shortcut">⌘ K</span></button>
    <div className="nav-label">WORKSPACE</div>
    <button className="nav-item active"><Layers3 size={17}/> Intelligence studio <span className="nav-counter">4</span></button>
    <button className="nav-item" onClick={()=>document.querySelector('#samples')?.scrollIntoView({behavior:'smooth'})}><History size={17}/> Sample library</button>
    <div className="nav-label nav-label-modes">INTELLIGENCE LENSES</div>
    {MODES.map(m=>{const I=MODE_ICONS[m.id];return <button key={m.id} onClick={()=>{onChange(m.id);onClose()}} className={`nav-item ${active===m.id?'mode-active':''}`}><I size={17}/><span>{m.product}</span>{active===m.id&&<span className="active-spark"/>}</button>})}
    <div className="sidebar-divider"/>
    <div className="nav-label">YOUR SPACE</div>
    <button className="nav-item" onClick={()=>document.querySelector('#samples')?.scrollIntoView({behavior:'smooth'})}><FolderOpen size={17}/> Investigations</button>
    <button className="nav-item" onClick={()=>document.querySelector('#how-it-works')?.scrollIntoView({behavior:'smooth'})}><HelpCircle size={17}/> How it works</button>
   </div>
   <div className="sidebar-bottom">
    <div className="sandbox-card"><div className="sandbox-top"><Sparkles size={16}/><span>Prototype environment</span></div><p>Explore the interaction design with labeled sample findings. Connect the backend for live intelligence.</p><div className="sandbox-footer"><StatusDot/> Demonstration data</div></div>
    <div className="profile-row"><div className="profile-avatar">C</div><div><strong>Local workspace</strong><span>Design prototype</span></div><MoreHorizontal size={17}/></div>
   </div>
  </aside>
 </>
}

function ModeSelector({active,onChange}){
 return <div className="mode-selector" role="tablist" aria-label="Intelligence lens">{MODES.map(m=>{const I=MODE_ICONS[m.id];return <button key={m.id} role="tab" aria-selected={active===m.id} onClick={()=>onChange(m.id)} className={`mode-tab ${active===m.id?'selected':''}`}><span className="mode-tab-icon"><I size={18}/></span><span className="mode-tab-text"><strong>{m.name}</strong><span>{m.product}</span></span>{active===m.id&&<span className="mode-selection-dot"/>}</button>})}</div>
}

function VideoOverlay({mode,focused,onInspect,obscure}){
 if(mode==='prelude') return <div className="video-intelligence-layer prelude-layer"><div className="tracking-box one"><span>ACTOR 01 · tracked</span></div><div className="tracking-box two"><span>ACTOR 02 · estimated</span></div><svg className="motion-paths" viewBox="0 0 720 405" preserveAspectRatio="none"><path d="M282 260 Q312 300 445 363" fill="none" stroke="#a9caff" strokeWidth="2.1" strokeDasharray="7 6"/><path d="M578 248 Q515 309 445 363" fill="none" stroke="#ffc992" strokeWidth="2.1" strokeDasharray="7 6"/><circle cx="445" cy="363" r="22" fill="#faad65" fillOpacity=".10" stroke="#faad65" strokeWidth="1.5"/></svg><div className="video-event-tag prelude-tag"><CircleAlert size={15}/> Potential path overlap <span>Illustrative</span></div></div>
 if(mode==='veil') return <div className="video-intelligence-layer veil-layer"><div className={`screen-region ${obscure?'protected':''}`}><span>{obscure?'SYNTHETIC MASK PREVIEW':'SCREEN AREA · REVIEW'}</span>{obscure&&<div className="mask-text">Protected preview</div>}</div><div className="video-event-tag veil-tag"><ShieldCheck size={15}/> {obscure?'Mask preview enabled':'Sensitive area to review'} <span>Illustrative</span></div></div>
 if(mode==='control') return <div className="video-intelligence-layer control-layer"><div className="control-outline one"><span>VARIABLE A</span></div><div className="control-outline two"><span>VARIABLE B</span></div><div className="video-event-tag control-tag"><Beaker size={15}/> Two variables change <span>Illustrative</span></div></div>
 return <div className="video-intelligence-layer context-layer"><div className="caption-strip"><MessageSquareQuote size={15}/><div><span>Transcript excerpt</span><strong>“...the result depends on the conditions...”</strong></div></div><div className="video-event-tag context-tag"><CircleAlert size={15}/> Missing surrounding context <span>Illustrative</span></div></div>
}

function VideoWorkspace({mode,scenario,customVideo,customDuration,onCustomDuration,position,setPosition,play,setPlay,overlay,setOverlay,focused,onInspect,mask,setMask,onUpload,onExpand,toast}){
 const ref=useRef(null)
 const duration=customVideo ? (customDuration||scenario.duration):scenario.duration
 const normalized=range(position,0,duration)
 const updatePlay=()=>{if(customVideo&&ref.current){if(ref.current.paused){ref.current.play().catch(()=>{});setPlay(true)}else{ref.current.pause();setPlay(false)}}else setPlay(!play)}
 const scrub=v=>{setPosition(v);if(customVideo&&ref.current) ref.current.currentTime=v}
 useEffect(()=>{if(!play||customVideo)return;let t=setInterval(()=>setPosition(p=>p+0.1>=duration?0:p+0.1),100);return()=>clearInterval(t)},[play,customVideo,duration,setPosition])
 useEffect(()=>{if(!customVideo){setPlay(false)}},[mode,customVideo,setPlay])
 return <div className="workspace-card">
  <div className="workspace-card-head"><div><Eyebrow>ACTIVE WORKSPACE <span className="bullet">·</span> {scenario.tag.toUpperCase()}</Eyebrow><h2>{customVideo?'Your video · awaiting analysis':scenario.title}</h2><p>{customVideo?'Preview only. Connect an analysis backend for findings.':scenario.short}</p></div><div className="workspace-actions"><button className="quiet-button" onClick={()=>toast('Sample project: no saved report yet')}><Bookmark size={16}/> Save</button><IconButton icon={Expand} label="Expand viewer" onClick={onExpand}/></div></div>
  <div className="video-shell">
    <div className="video-stage" style={!customVideo?{backgroundImage:`linear-gradient(0deg,rgba(8,12,18,.78),rgba(8,12,18,.06) 65%),url("${scenario.image}")`}:undefined}>
     {customVideo&&<video ref={ref} className="actual-video" src={customVideo} playsInline onTimeUpdate={e=>setPosition(e.currentTarget.currentTime)} onLoadedMetadata={e=>{onCustomDuration?.(e.currentTarget.duration);setPosition(0)}} onEnded={()=>setPlay(false)}/>}
     <div className="video-stage-top"><span className="stage-chip"><StatusDot state={customVideo?'idle':'ready'}/> {customVideo?'LOCAL FILE · NOT ANALYZED':scenario.label}</span><button className="overlay-control" onClick={()=>setOverlay(!overlay)}>{overlay?<Eye size={15}/>:<EyeOff size={15}/>} Overlay {overlay?'on':'off'}</button></div>
     {!customVideo&&overlay&&<VideoOverlay mode={mode} focused={focused} onInspect={onInspect} obscure={mask}/>}
     {!play&&<button className="center-play" onClick={updatePlay} aria-label="Play video"><Play size={22} fill="currentColor"/></button>}
     <div className="stage-bottom"><div className="stage-info"><span className="stage-info-kicker">{customVideo?'LOCAL PREVIEW':'INTERACTIVE SAMPLE'}</span><span>{customVideo?'No analysis performed':scenario.flag}</span></div><button className="stage-inspect" onClick={onInspect}>Inspect evidence <ArrowRight size={15}/></button></div>
    </div>
    <div className="playback-controls"><div className="playhead-wrap"><input className="scrubber" aria-label="Video position" type="range" min="0" max={duration} step="0.1" value={normalized} onChange={e=>scrub(Number(e.target.value))} style={{'--progress':`${normalized/duration*100}%`}}/>{!customVideo&&scenario.facts.map((f,i)=><button key={f.id} className={`scrubber-marker ${f.severity}`} style={{left:`${f.time/duration*100}%`}} title={f.label} onClick={()=>scrub(f.time)}/>)}</div>
     <div className="playback-bar"><div className="playback-left"><IconButton icon={SkipBack} label="Back 5 seconds" onClick={()=>scrub(range(position-5,0,duration))}/><button className="playback-primary" onClick={updatePlay} aria-label={play?'Pause':'Play'}>{play?<Pause size={17} fill="currentColor"/>:<Play size={17} fill="currentColor"/>}</button><IconButton icon={SkipForward} label="Forward 5 seconds" onClick={()=>scrub(range(position+5,0,duration))}/><span className="video-time">{clock(position)} <span>/</span> {clock(duration)}</span></div><div className="playback-right"><button className="small-control" onClick={()=>toast('Audio is controlled by your video. Sample preview has no audio.')}><Volume2 size={16}/></button><button className="playback-speed" onClick={()=>toast('Sample playback runs at 1× speed')}>1×</button><IconButton icon={Expand} label="Expand viewer" onClick={onExpand}/></div></div>
    </div>
  </div>
  <div className="workspace-bottom"><div className="small-metric"><span className="metric-icon"><ScanEye size={15}/></span><span><strong>{customVideo?'Not analyzed':`${scenario.facts.length} findings`}</strong><small>{customVideo?'Connect engine for results':'Illustrative evidence'}</small></span></div><div className="small-metric"><span className="metric-icon"><Clock3 size={15}/></span><span><strong>{clock(duration)}</strong><small>Media duration</small></span></div><div className="small-metric"><span className="metric-icon"><Layers3 size={15}/></span><span><strong>{customVideo?'No sources':`${scenario.sources.length} sources`}</strong><small>{customVideo?'No analysis performed':'Example references'}</small></span></div>{mode==='veil'&&!customVideo&&<label className="mask-switch"><input type="checkbox" checked={mask} onChange={e=>setMask(e.target.checked)}/> <span>Preview protection</span></label>}</div>
 </div>
}

function IntelligencePanel({mode,scenario,focused,setFocused,position,setPosition,customVideo,activeTab,setActiveTab,onReveal}){
 const [expanded,setExpanded]=useState(null)
 useEffect(()=>setExpanded(null),[mode])
 return <aside className="intel-panel" id="insights"><div className="intel-panel-top"><div><Eyebrow>INTELLIGENCE PANEL</Eyebrow><h3>What we notice <span className="count-pill">{customVideo?0:scenario.facts.length}</span></h3></div><div className="intelligence-glyph"><Sparkles size={18}/></div></div>
 <div className="intel-status"><div className="intel-status-head"><StatusDot state={customVideo?'idle':'ready'}/><strong>{customVideo?'Analysis not connected':'Preview findings'}</strong><span>{customVideo?'Offline':'Sample'}</span></div><p>{customVideo?'Your video stays in your browser. The prototype does not claim to have analyzed it.':'These are seeded interaction examples, not actual model outputs.'}</p></div>
 <div className="panel-tabs"><button className={activeTab==='findings'?'current':''} onClick={()=>setActiveTab('findings')}>Findings {customVideo?'':`(${scenario.facts.length})`}</button><button className={activeTab==='sources'?'current':''} onClick={()=>setActiveTab('sources')}>Sources {customVideo?'':`(${scenario.sources.length})`}</button></div>
 <div className="findings-body">
  {customVideo?<div className="empty-analysis"><ScanEye size={28}/><strong>Ready for an engine</strong><p>The interface is working, but there is no real analyzer connected. No fabricated result is shown.</p></div>:
  activeTab==='findings'?scenario.facts.map((f,i)=>{const opened=expanded===f.id;return <button key={f.id} className={`finding-card ${focused===i?'focus':''}`} onClick={()=>{setFocused(i);setPosition(f.time);setExpanded(opened?null:f.id)}}><span className={`finding-type ${f.severity}`}>{f.severity==='attention'?<CircleAlert size={15}/>:f.severity==='source'?<CircleCheck size={15}/>:<CircleHelp size={15}/>}</span><span className="finding-content"><span className="finding-top"><span className="finding-number">FINDING {String(i+1).padStart(2,'0')}</span><span className="finding-time">{clock(f.time)}</span></span><strong>{f.label}</strong><small>{f.sub}</small>{opened&&<span className="finding-detail">{f.detail}<span className="finding-open">Jumped to {clock(f.time)} <ArrowRight size={13}/></span></span>}</span><ChevronDown size={15} className={`finding-chevron ${opened?'rotate':''}`}/></button>}):scenario.sources.map((s,i)=><div className="source-card" key={i}><div className="source-visual"><FileText size={19}/></div><div><strong>{s.title}</strong><p>{s.meta}</p><span>{s.kind}</span></div><span className="source-illustration">Sample</span></div>)}
 </div>
 <div className="panel-footer"><div className="evidence-note"><Shield size={15}/><span>Evidence is not certainty. Interpretations always need sources.</span></div><button className="panel-action" onClick={onReveal}>Explore evidence <ArrowRight size={16}/></button></div>
 </aside>
}

function Timeline({scenario,mode,position,setPosition,customVideo,onReveal}){
 const ratio=customVideo?0:position/scenario.duration*100
 return <section className="timeline-card"><div className="section-head"><div><Eyebrow>TIME-ALIGNED INTELLIGENCE</Eyebrow><h3>Explore the sequence</h3></div><div className="timeline-header-right"><span><i className="legend-dot matched"/> Supported</span><span><i className="legend-dot question"/> Review</span><button className="quiet-button" onClick={onReveal}><ArrowLeftRight size={15}/> Compare</button></div></div>
 <div className="timeline-content">{customVideo?<div className="empty-timeline"><Video size={20}/> Timeline will populate when a processing engine returns timestamped evidence.</div>:<>
  <div className="timeline-row"><div className="track-label"><span>ORIGINAL</span><small>Reference</small></div><div className="track-track"><div className="track-region original-a" style={{left:'0%',width:'29%'}}>Segment A</div><div className="track-region original-gap" style={{left:'29%',width:'28%'}}>Context to review</div><div className="track-region original-b" style={{left:'57%',width:'43%'}}>Segment B</div></div></div>
  <div className="timeline-row"><div className="track-label"><span>SEQUENCE</span><small>Observed</small></div><div className="track-track"><div className="track-region edited-a" style={{left:'0%',width:'50%'}}>Observed A</div><div className="track-region edited-b" style={{left:'50%',width:'50%'}}>Observed B</div></div></div>
  <div className="timeline-ruler"><span>00:00</span><span>{clock(scenario.duration*.25)}</span><span>{clock(scenario.duration*.5)}</span><span>{clock(scenario.duration*.75)}</span><span>{clock(scenario.duration)}</span></div>
  <div className="timeline-findings">{scenario.facts.map((f,i)=><button key={f.id} title={f.label} className="timeline-incident" style={{left:`${f.time/scenario.duration*100}%`}} onClick={()=>setPosition(f.time)}><span className={`timeline-incident-dot ${f.severity}`}/><span className="timeline-tooltip">{f.label}</span></button>)}<div className="timeline-playhead" style={{left:`${range(ratio,0,100)}%`}}/></div>
 </> }</div>
 <div className="timeline-bottom"><span><MousePointer2 size={14}/> Select any marker to jump to that point</span><span className="timeline-disclaimer">Sample data · no analysis performed</span></div>
 </section>
}

function SampleLibrary({active,onSelect}){return <section className="sample-section" id="samples"><div className="section-head"><div><Eyebrow>EXPERIENCE THE POSSIBILITIES</Eyebrow><h3>Choose a story to explore</h3></div><span className="muted-small">Four interactive sample scenarios</span></div><div className="sample-grid">{MODES.map(m=>{const s=SCENARIOS[m.id], I=MODE_ICONS[m.id];return <button className={`sample-card ${active===m.id?'is-current':''}`} key={m.id} onClick={()=>{onSelect(m.id);window.scrollTo({top:0,behavior:'smooth'})}}><div className="sample-image" style={{backgroundImage:`linear-gradient(0deg,rgba(10,14,21,.77),rgba(10,14,21,.1)),url("${s.image}")`}}><span className="sample-tag"><I size={13}/>{m.product}</span><div className="sample-cta"><ArrowRight size={16}/></div></div><div className="sample-copy"><strong>{s.title}</strong><small>{m.caption}</small></div></button>})}</div></section>}

function IntakeModal({onClose,onUpload,onToast}){
 const [url,setUrl]=useState('');const [tab,setTab]=useState('file');const file=useRef(null);const [drag,setDrag]=useState(false)
 const accept=files=>{const f=files?.[0];if(!f)return;if(!f.type.startsWith('video/'))return onToast('Choose a video file (MP4, MOV, WebM).');onUpload(f);onClose()}
 return <div className="modal-backdrop" onMouseDown={e=>{if(e.target===e.currentTarget)onClose()}}><div className="modal-card"><div className="modal-head"><div className="modal-icon"><Plus size={20}/></div><IconButton icon={X} label="Close" onClick={onClose}/></div><h2>Start with a video.</h2><p>Observe, investigate, anticipate, or protect—choose what you want to understand.</p><div className="modal-tabs"><button className={tab==='file'?'active':''} onClick={()=>setTab('file')}><Upload size={16}/> Upload file</button><button className={tab==='url'?'active':''} onClick={()=>setTab('url')}><Link2 size={16}/> Video URL</button></div>{tab==='file'?<div className={`upload-zone ${drag?'dragging':''}`} onDragOver={e=>{e.preventDefault();setDrag(true)}} onDragLeave={()=>setDrag(false)} onDrop={e=>{e.preventDefault();setDrag(false);accept(e.dataTransfer.files)}}><input type="file" accept="video/*" ref={file} onChange={e=>accept(e.target.files)} hidden/><div className="upload-icon"><Video size={23}/></div><strong>Drop your footage here</strong><span>MP4, MOV, WebM</span><button className="primary-button" onClick={()=>file.current?.click()}>Browse video <ArrowRight size={15}/></button></div>:<div className="url-upload"><label>Public video URL</label><input value={url} onChange={e=>setUrl(e.target.value)} placeholder="https://example.com/video"/><p>Direct URL ingestion and online source search require a connected backend.</p><button className="primary-button" onClick={()=>onToast('URL ingestion is not connected in this design prototype.')}>Continue <ArrowRight size={16}/></button></div>}<div className="modal-note"><ShieldCheck size={16}/> Uploaded files are previewed locally in this browser. No AI processing or remote upload occurs in this demo.</div></div></div>
}

function EvidenceDrawer({onClose,scenario,mode,customVideo,onJump}){
 return <><div className="drawer-scrim" onClick={onClose}/><aside className="evidence-drawer"><div className="drawer-head"><div><Eyebrow>EVIDENCE DOSSIER</Eyebrow><h2>{customVideo?'No investigation yet':scenario.title}</h2></div><IconButton icon={X} label="Close" onClick={onClose}/></div><div className="drawer-body"><div className="dossier-banner"><Fingerprint size={20}/><div><strong>{customVideo?'Requires analysis':'Illustrative case file'}</strong><p>{customVideo?'Connect your analysis API to generate evidence.':'The following findings are UX examples, not AI conclusions.'}</p></div></div><Eyebrow>OVERVIEW</Eyebrow><p className="drawer-overview">{customVideo?'This local file has not been submitted to an analyzer.':scenario.insight}</p><Eyebrow>TIME-CODED OBSERVATIONS</Eyebrow>{!customVideo&&scenario.facts.map((f,i)=><button key={f.id} className="drawer-finding" onClick={()=>{onJump(f.time);onClose()}}><span>{clock(f.time)}</span><div><strong>{f.label}</strong><p>{f.detail}</p></div><MoveUpRight size={15}/></button>)}<Eyebrow>PROVENANCE & LIMITATIONS</Eyebrow><div className="limitations"><CircleHelp size={18}/><p>Sample visual assets are not source videos. Real verification requires independent evidence, timestamped matching and model uncertainty. Demo findings must never be presented as measured results.</p></div></div><div className="drawer-footer"><button className="primary-button" onClick={onClose}>Back to viewer <ArrowRight size={15}/></button></div></aside></>
}

function Toast({message,onClose}){useEffect(()=>{if(!message)return;let x=setTimeout(onClose,4000);return()=>clearTimeout(x)},[message,onClose]);return message?<div className="toast"><CircleHelp size={16}/><span>{message}</span><button onClick={onClose}><X size={14}/></button></div>:null}

function App(){
 const [mode,setMode]=useState('context');const [theme,setTheme]=useState('dark');const [mobileOpen,setMobileOpen]=useState(false)
 const [position,setPosition]=useState(31),[playing,setPlaying]=useState(false),[overlay,setOverlay]=useState(true),[selected,setSelected]=useState(1)
 const [intake,setIntake]=useState(false),[evidence,setEvidence]=useState(false),[expanded,setExpanded]=useState(false),[tab,setTab]=useState('findings'),[mask,setMask]=useState(false)
 const [customVideo,setCustomVideo]=useState(null),[customDuration,setCustomDuration]=useState(null),[toast,setToast]=useState('')
 const scenario=SCENARIOS[mode], active=MODES.find(m=>m.id===mode)
 const changeMode=m=>{setMode(m);setPosition(0);setPlaying(false);setSelected(0);setTab('findings');setMask(false);if(customVideo){URL.revokeObjectURL(customVideo);setCustomVideo(null);setCustomDuration(null)}}
 const upload=f=>{if(customVideo)URL.revokeObjectURL(customVideo);setCustomVideo(URL.createObjectURL(f));setCustomDuration(null);setPosition(0);setPlaying(false);setSelected(-1);setToast(`Loaded ${f.name}. This preview does not run AI analysis.`)}
 const notify=useCallback(m=>setToast(m),[])
 useEffect(()=>{const onKey=e=>{if((e.metaKey||e.ctrlKey)&&e.key.toLowerCase()==='k'){e.preventDefault();setIntake(true)}if(e.key==='Escape'){setIntake(false);setEvidence(false);setExpanded(false)}};window.addEventListener('keydown',onKey);return()=>window.removeEventListener('keydown',onKey)},[])
 return <div className={`app-root ${theme==='light'?'theme-light':'theme-dark'}`}>
  <Sidebar active={mode} onChange={changeMode} mobileOpen={mobileOpen} onClose={()=>setMobileOpen(false)} onNew={()=>setIntake(true)}/>
  <main className="main-area"><header className="topbar"><div className="topbar-left"><button className="mobile-menu icon-button" onClick={()=>setMobileOpen(true)}><Menu size={19}/></button><span>Workspace</span><ChevronRight size={14}/><strong>Intelligence studio</strong></div><div className="topbar-actions"><span className="live-demo"><StatusDot/> Interface preview</span><IconButton icon={theme==='dark'?Sun:Moon} label="Toggle light and dark mode" onClick={()=>setTheme(theme==='dark'?'light':'dark')}/><IconButton icon={Bell} label="Notifications" onClick={()=>notify('No notifications in this prototype')}/><span className="top-avatar">C</span></div></header>
  <div className="content-wrap"><section className="hero-section"><div className="hero-label"><Sparkles size={15}/> THE VIDEO INTELLIGENCE WORKSPACE <span className="hero-version">CONCEPT / 01</span></div><div className="hero-heading-row"><div><h1>See more than <em>what's shown.</em></h1><p>One lens for every story. Understand context, anticipate risk, protect privacy, and explore what evidence really proves.</p></div><button className="primary-button hero-action" onClick={()=>setIntake(true)}><Plus size={18}/> New investigation <ArrowRight size={16}/></button></div></section>
  <ModeSelector active={mode} onChange={changeMode}/>
  <div className="mode-context"><div className="mode-context-text"><span className="mode-product">{active.product} <span>/</span> {active.name}</span><h2>{active.subtitle}</h2><p>{active.caption}</p></div><button className="quiet-button mode-help" onClick={()=>notify(`${active.product} is a conceptual lens. The active findings are sample data.`)}><CircleHelp size={15}/> About this lens</button></div>
  <div className="workspace-grid"><VideoWorkspace mode={mode} scenario={scenario} customVideo={customVideo} customDuration={customDuration} onCustomDuration={setCustomDuration} position={position} setPosition={setPosition} play={playing} setPlay={setPlaying} overlay={overlay} setOverlay={setOverlay} focused={selected} onInspect={()=>setEvidence(true)} mask={mask} setMask={setMask} onUpload={()=>setIntake(true)} onExpand={()=>setExpanded(true)} toast={notify}/><IntelligencePanel mode={mode} scenario={scenario} focused={selected} setFocused={setSelected} position={position} setPosition={setPosition} customVideo={customVideo} activeTab={tab} setActiveTab={setTab} onReveal={()=>setEvidence(true)}/></div>
  <Timeline scenario={scenario} mode={mode} position={position} setPosition={setPosition} customVideo={customVideo} onReveal={()=>setEvidence(true)}/>
  <SampleLibrary active={mode} onSelect={changeMode}/>
  <section className="why-section" id="how-it-works"><div className="why-icon"><Sparkles size={19}/></div><div><strong>Intelligence should come with evidence.</strong><p>One shared engine can power multiple ways of understanding video, but each conclusion must link to actual observations and acknowledge uncertainty.</p></div><button onClick={()=>setEvidence(true)}>Explore the principle <ArrowRight size={15}/></button></section>
  <footer className="site-footer"><span>context. / A vision intelligence concept</span><span>Built with React · Tailwind CSS · Lucide</span><span>Demo content only · Not live AI results</span></footer></div>
  </main>
  {intake&&<IntakeModal onClose={()=>setIntake(false)} onUpload={upload} onToast={notify}/>}
  {evidence&&<EvidenceDrawer scenario={scenario} mode={mode} customVideo={customVideo} onJump={setPosition} onClose={()=>setEvidence(false)}/>}
  {expanded&&<div className="fullscreen-view" onClick={e=>{if(e.target===e.currentTarget)setExpanded(false)}}><div className="fullscreen-dialog"><div className="fullscreen-head"><span><ScanEye size={17}/> {scenario.title}</span><IconButton icon={X} label="Close" onClick={()=>setExpanded(false)}/></div><div className="fullscreen-stage" style={{backgroundImage:`linear-gradient(0deg,rgba(8,12,18,.5),transparent),url('${scenario.image}')`}}><span>Sample preview · source media not connected</span></div></div></div>}
  <Toast message={toast} onClose={()=>setToast('')}/>
 </div>
}
export default App
