# CONTEXT Vision Studio — Product UX specification

## Concept
One shared video intelligence workspace, four investigative lenses. The user keeps the same video, playhead, temporal history, and evidence drawer while changing the *question* being asked:

- **CONTEXT · Investigate** — “What's the full story?” provenance, missing context, visual/voice claims, comparison, citations.
- **PRELUDE · Anticipate** — “What might happen next?” tracked actors, motion paths, possible conflicts, uncertainty. Never promise reliable driving assistance.
- **VEIL · Protect** — “What should stay private?” sensitive regions, track coverage, previewed transformation, independent export audit.
- **CONTROL · Experiment** — “What does the evidence prove?” variables, state changes, confounds, control suggestions.

This prototype intentionally uses seeded sample scenarios. User-uploaded files are **local previews only**, never labeled as analyzed. An upload does not fabricate model findings.

## Primary desktop screen

- **Left navigation**: the studio, sample gallery, and the four lenses. Shortcuts should be discoverable but quiet.
- **Headline/intake**: one new-investigation action; don't ask users to choose specialized models or pipelines.
- **Lens switcher**: purpose-driven verbs (Investigate, Anticipate, Protect, Experiment), each labeled with product name.
- **Video-first workspace**: a large 16:9 viewer, overlay toggle, play/pause, scrubber, linked evidence markers, expandable frame view.
- **Intelligence panel**: ranked findings (not a chat transcript), evidence/sources tabs, uncertainty, actionable inspect controls.
- **Time-aligned evidence**: distinguish observed footage, verified sources, and unverified suggestions; clicking a marker seeks the player.
- **Case gallery**: a small set of demo scenarios for immediate onboarding and mode exploration.
- **Evidence dossier**: drawer with provenance and limitations, reachable from every finding.

## A note on trust
Visual elements must not imply stronger certainty than the underlying engine supports:

1. `observed` — directly measured, timestamped media facts.
2. `matched` — source alignment or derived relation with method and scores.
3. `inferred` — model interpretation that requires scrutiny.
4. `unverified` — insufficient evidence; never implicitly label false or safe.

For PRELUDE: a risk cue is **not** a validated collision probability. For VEIL: seeing a mask is **not** a privacy certificate. For CONTROL: an observed confound is **not** proof of causation. For CONTEXT: editing is **not** synonymous with deception.

## Motion and accessibility

- Buttons, cards and tabs use 150–300ms transitions, motion limited to small translation and subtle shadow/tint change.
- Entrance motion is a short fade and rise. Respect `prefers-reduced-motion`.
- Color conveys role but not status alone; text or icon reinforces every critical warning.
- Maintain keyboard focus outlines, usable hit targets and semantic button labels.
- Provide light and dark themes, plus responsive navigation under tablet/mobile breakpoints.
- Display an explicit state for unsupported URLs, missing analyzers, unprocessed uploads, and empty findings.

## Integration boundary

The production frontend should consume a job/event-oriented API. A shared video-core provides temporal observations; each domain adapter produces domain-specific findings with evidence references.

```ts
export type SourceReference = {
  id: string;
  title: string;
  uri?: string;
  videoId?: string;
  startSeconds?: number;
  endSeconds?: number;
};

export type VideoObservation = {
  id: string;
  kind: string;
  modality: 'visual' | 'audio' | 'metadata' | 'cross-modal';
  startSeconds: number;
  endSeconds?: number;
  geometry?: { x: number; y: number; width: number; height: number };
  summary: string;
  evidence: SourceReference[];
  epistemicStatus: 'observed' | 'matched' | 'inferred' | 'unverified';
  uncertainty?: string;
};

export type InvestigationResult = {
  id: string;
  mode: 'context' | 'prelude' | 'veil' | 'control';
  media: { url: string; durationSeconds: number };
  status: 'queued' | 'running' | 'completed' | 'partial' | 'failed';
  observations: VideoObservation[];
  sources: SourceReference[];
};
```

The interface is intended to be integrated into the existing functional CONTEXT codebase as a frontend design and UX reference, not as a replacement for its video matching/Meta models.

## Suggested path to production

**Milestone 1**: Replace the seeded CONTEXT scenario with an actual `InvestigationResult`. Keep the existing engine. Verify player-to-evidence timestamp parity.

**Milestone 2**: Add true case loading, upload job state, source discovery and retrieved evidence. Hide demo labels for analyzed results only.

**Milestone 3**: Introduce PRELUDE/VEIL/CONTROL adapters with explicit per-mode capability states and independent evaluation.

**Milestone 4**: Export immutable evidence dossiers and (where justified) privacy-safe clips. Include audit metadata.
