# CONTEXT — Vision Intelligence Studio (UI Prototype)

A polished, responsive React + Tailwind + Lucide interface exploring four related video-intelligence experiences:

- **CONTEXT — Investigate:** Authenticity, evidence, source discovery, missing context.
- **PRELUDE — Anticipate:** Tracking and early-risk visualization (not a validated safety tool).
- **VEIL — Protect:** Sensitive region review and privacy-aware export workflows.
- **CONTROL — Experiment:** Observations, changing variables, and scientific reasoning.

## Open an instant, dependency-free preview

Open `preview.html` in any modern browser. The preview is a standalone HTML file with embedded CSS and four bundled vector-backed scenarios. It contains working UI interactions but **no real AI analysis**.

## Run the full React application

```bash
npm install
npm run dev
```

Open the Vite URL shown in your terminal.

## Interactive prototype features

- Four task-specific modes sharing a consistent video-first workspace.
- Interactive video timeline, clickable timestamps, contextual overlays, and evidence dossier drawer.
- Dark/light mode and responsive mobile navigation.
- Sample-case switcher, playback controls, upload or drag-and-drop **local video preview**.
- Privacy preview toggle, keyboard shortcut `⌘/Ctrl + K` for new investigation.
- Honest empty state for real uploaded footage: **no AI inference is running**.

## Backend contract

To connect the actual video-intelligence service, replace seeded `SCENARIOS` data in `src/data.js` with a typed `Investigation` response delivered by your backend. Suggested primitives:

```ts
type Investigation = {
  id: string;
  mode: 'context' | 'prelude' | 'veil' | 'control';
  media: {url: string; durationSeconds: number};
  observations: Array<{
    id: string;
    startSeconds: number;
    endSeconds?: number;
    type: string;
    description: string;
    provenance: string[];
    uncertainty?: string;
  }>;
  sources?: Array<{title: string; uri: string; mediaTimeSeconds?: number}>;
};
```

**Integrity principle:** Never present inference or fictional demo data as validated truth, safety predictions, or privacy guarantees. Model outputs require provenance and evaluation.

## Assets

The four scene backdrops are original SVG illustrations, bundled in `public/scenes/` and embedded into the standalone preview. They are illustrative only and do not correspond to actual model findings.

## Design choices

Single vibrant periwinkle accent. Restrained semantic amber/green reserved for tentative findings. Inter/system-ui. 150–300ms interaction transitions. Card layout, accessible focus, responsive breakpoints, reduced-motion support.

This is a **frontend UX design prototype**, not a working video analyzer. Connect Muse Spark, SAM, Voice, retrieval, alignment, and privacy modules separately.


## Product UX map

- **Global home / intake**: One video upload (local preview); select the intelligence lens.
- **CONTEXT**: Evidence-first investigation, source tabs, missing context and timecoded claims.
- **PRELUDE**: Object-track boxes and possible path conflicts (non-operational safety concept).
- **VEIL**: Sensitive-region overlay, interactive mask preview, export-audit concept.
- **CONTROL**: Experimental variables, observations, confounds and control suggestions.
- **Cross-cutting**: Persistent video viewer, evidence dossier drawer, clickable timeline markers, keyboard shortcut, theme toggle, responsive sidebar.

### Production integration contract

Use a single time-indexed `Observation` data model with fields for modality, provenance, timestamps, spatial geometry, inferred interpretation and uncertainty. Each intelligence lens should be a domain-specific adapter that outputs the same primitives. Never treat seeded prototype findings as backend results. A separate analysis job state (queued / running / completed / partial / failed) should accompany real uploads.

### Verification completed in this environment

- Validated the bundled standalone preview's JavaScript using `node --check`.
- Parsed the React JSX modules using TypeScript's `transpileModule` (syntax check).
- Full Vite runtime build was **not** executed because npm package installation could not reach the registry in this environment. Run `npm install && npm run build` on a networked developer machine.
